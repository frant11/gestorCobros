package com.cobros;

import java.util.Scanner;

public class Actualizar extends Cuenta {

    int numeroCuenta = getNumeroCuenta();
    String nombre = getNombre();
    int dui = getDui();

    public Actualizar() {
    }

    public Cuenta actualizarCuenta(int numCuenta) {
        Scanner input = new Scanner(System.in);
        if (numCuenta == numeroCuenta) {
            Cuenta c = new Cuenta();
            c.setNumeroCuenta(numeroCuenta);
            c.setNombre(nombre);
            c.setDui(dui);
            System.out.println("Ingrese el nuevo correo de cliente");
            c.setCorreo(input.nextLine());
            System.out.println("Ingrese el nuevo nombre de producto: ");
            c.setProducto(input.nextLine());
            System.out.println("Ingrese el nuevo Monto producto: ");
            c.setMonto(input.nextDouble());
            System.out.println("Ingrese la nueva cuota: ");
            c.setCuota(input.nextDouble());
            input.nextLine();
            System.out.println("Ingrese el nuevo estado de la cuenta: ");
            c.setEstado(input.nextLine());
            System.out.println("Datos actualizados correctamente");
            String producto = c.getProducto();
            int numeroCuenta = getNumeroCuenta();
            String nombre = getNombre();
            int dui = getDui();
            double monto = c.getMonto();
            double cuota = c.getCuota();
            String estado = c.getEstado();
            String correo = c.getCorreo();

            System.out.println("nuevo correo: "+correo);
            c.cuentaActualizada(numeroCuenta,nombre,dui,producto,monto,cuota,estado,correo);
            return c;
        }
        return null;

    }
}