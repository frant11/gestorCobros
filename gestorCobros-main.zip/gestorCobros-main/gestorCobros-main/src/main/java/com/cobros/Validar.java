package com.cobros;

public interface Validar {
    public Cuenta validarPago(int numeroCuenta);
}
