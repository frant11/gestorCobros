package com.cobros;

public interface Update {

    public Cuenta actualizarCuenta(int numCuenta);

}
