package com.cobros;

import java.util.Scanner;

public class ValidarPago extends Cuenta{
    Cuenta validacion = null;

    @Override
    public int getNumeroCuenta() {
        return super.getNumeroCuenta();
    }



    double montoAdeudado;

    {
        montoAdeudado = getMonto();
    }

    public Cuenta validarPago(int numeroCuenta) {
        Cuenta validar = new Cuenta();
        String opcion = "";
        numeroCuenta = getNumeroCuenta();
        Scanner entrada = new Scanner(System.in);
        if(numeroCuenta==getNumeroCuenta())
        {
            System.out.println("El cliente efectuo el pago?");
            opcion = entrada.nextLine();
            if (opcion.equals("si"))
            {
                EstadoCuenta ec = new EstadoCuenta();
                ec.estadoCuenta(numeroCuenta);
            } else if (!opcion.equals("si")) {
                validar.setMonto(validar.getMonto());
                double monto = validar.getMonto();
                double interes = 0.10;
                double nuevoMonto = monto+(validar.getMonto() * interes);
                validar.validarPago(nuevoMonto);
                setMonto(nuevoMonto);
                System.out.println("Monto Actualizado");
            }

        }


       return validacion = validar;


    }
}

