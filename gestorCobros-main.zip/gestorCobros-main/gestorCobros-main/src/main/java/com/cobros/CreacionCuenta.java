package com.cobros;

public interface CreacionCuenta {
  public Cuenta CrearCuenta();
}
