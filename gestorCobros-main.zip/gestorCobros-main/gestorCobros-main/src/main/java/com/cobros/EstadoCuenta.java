package com.cobros;

import org.w3c.dom.ls.LSOutput;

import java.io.*;
import java.util.Map;

public class EstadoCuenta extends Principal {
    Cuenta c = new Cuenta();
    File file = new File("C:\\Users\\augus\\OneDrive\\Desktop\\Recibos\\recibo.txt");
    BufferedWriter bf = null;

    public Cuenta estadoCuenta(int numeroCuenta) {

        try {
            for (Map.Entry<Integer, Cuenta> entry : listaCuentas.entrySet()) {

                String mensaje = "Gracias por su pago" + "******************" + "\nCuenta: "
                        + entry.getKey() + "\nNombre: " + entry.getValue().getNombre() + "\nDui: " + entry.getValue().getDui() + "\nProducto: "
                        + entry.getValue().getProducto() + "\nCuota: " + entry.getValue().getCuota();
                file.createNewFile();
                bf = new BufferedWriter(new FileWriter(file));
                bf.write(mensaje);
                System.out.println("El archivo se creo...");

            }
            bf.flush();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return c;
    }


}
