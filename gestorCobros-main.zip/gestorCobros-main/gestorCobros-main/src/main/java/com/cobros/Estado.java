package com.cobros;

public interface Estado {
    public Cuenta estadoCuenta(int numeroCuenta);

}
